import cv2
import numpy as np
import mediapipe as mp
import pyttsx3
import threading
import math

# Initialize mediapipe and TTS
mp_drawing = mp.solutions.drawing_utils
mp_pose = mp.solutions.pose
engine = pyttsx3.init()

def speak(text):
    def _speak():
        engine.say(text)
        engine.runAndWait()
    threading.Thread(target=_speak).start()

def calculate_angle(a, b, c):
    a, b, c = np.array(a), np.array(b), np.array(c)
    radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
    angle = np.abs(radians * 180.0 / np.pi)
    return angle if angle <= 180.0 else 360 - angle

cap = cv2.VideoCapture(0)

# Ghost logic variables
buffer = 15
upper_arm_len = 90
lower_arm_len = 90
ghost_sequence = [-90, 5, 90]  # Sequence of target angles
current_ghost_index = 0  # Start at -90°

def get_ghost_angles(current_step):
    # Define the ghost arm sequence based on the current step
    if current_step == -90:
        return [5, 90]  # Show both 5° and 90° at -90°
    elif current_step == 5:
        return [90]  # Show only 90° at 5°
    elif current_step == 90:
        return [-90, 5]  # Show -90° and 5° at 90°
    return []

def check_transition(shoulder_angle):
    global current_ghost_index
    target_angle = ghost_sequence[current_ghost_index]
    if abs(shoulder_angle - abs(target_angle)) <= buffer:
        # Move to the next angle in the sequence
        current_ghost_index = (current_ghost_index + 1) % len(ghost_sequence)

# Rep counter
counter = 0
target_reps = int(input("Enter number of reps: "))
rep_completed = False
stage = "down"
elbow_warning_issued = False

with mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose:
    while cap.isOpened():
        ret, frame = cap.read()
        frame = cv2.flip(frame, 1)
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image.flags.writeable = False
        results = pose.process(image)
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        try:
            landmarks = results.pose_landmarks.landmark
            shoulder = [landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                        landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y]
            elbow = [landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                     landmarks[mp_pose.PoseLandmark.LEFT_ELBOW.value].y]
            wrist = [landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                     landmarks[mp_pose.PoseLandmark.LEFT_WRIST.value].y]
            hip = [landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].x,
                   landmarks[mp_pose.PoseLandmark.LEFT_HIP.value].y]

            shoulder_px = np.multiply(shoulder, [640, 480]).astype(int)
            shoulder_angle = calculate_angle(hip, shoulder, elbow)
            elbow_angle = calculate_angle(shoulder, elbow, wrist)

            # Elbow straightness check
            if elbow_angle < 160:
                if not elbow_warning_issued:
                    speak("Straighten your elbow")
                    elbow_warning_issued = True
                cv2.putText(image, "Elbow bent", (50, 150),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            else:
                elbow_warning_issued = False

            # Repetition logic
            if shoulder_angle < 30:
                stage = "down"
                if rep_completed:
                    counter += 1
                    rep_completed = False
                    speak(f"Rep {counter}")
                    print(f"Rep: {counter}")
                    if counter >= target_reps:
                        speak("Great job! You smashed your goal.")
                        cv2.putText(image, "Great job!", (50, 200),
                                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 3)
                        cv2.imshow('Mediapipe Feed', image)
                        cv2.waitKey(2000)
                        break
            elif shoulder_angle > 170 and stage == "down":
                stage = "up"
                rep_completed = True

            # Ghost logic
            check_transition(shoulder_angle)
            ghost_angles = get_ghost_angles(ghost_sequence[current_ghost_index])

            for angle in ghost_angles:
                angle_rad = math.radians(angle)
                ghost_elbow = [
                    shoulder_px[0] + upper_arm_len * math.cos(angle_rad),
                    shoulder_px[1] - upper_arm_len * math.sin(angle_rad)
                ]
                ghost_wrist = [
                    ghost_elbow[0] + lower_arm_len * math.cos(angle_rad),
                    ghost_elbow[1] - lower_arm_len * math.sin(angle_rad)
                ]
                cv2.line(image, tuple(shoulder_px), tuple(np.int32(ghost_elbow)), (255, 0, 0), 2)
                cv2.line(image, tuple(np.int32(ghost_elbow)), tuple(np.int32(ghost_wrist)), (255, 0, 0), 2)
                cv2.circle(image, tuple(shoulder_px), 4, (255, 0, 0), -1)
                cv2.circle(image, tuple(np.int32(ghost_elbow)), 4, (255, 0, 0), -1)
                cv2.circle(image, tuple(np.int32(ghost_wrist)), 4, (255, 0, 0), -1)

        except Exception:
            pass

        # UI overlay
        cv2.rectangle(image, (0, 0), (225, 73), (245, 117, 16), -1)
        cv2.putText(image, 'REPS', (15, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
        cv2.putText(image, str(counter), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 2)

        if results.pose_landmarks:
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)

        cv2.imshow('Mediapipe Feed', image)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()